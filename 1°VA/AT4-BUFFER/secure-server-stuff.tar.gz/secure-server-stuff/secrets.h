int isValidPassword(char *input);
